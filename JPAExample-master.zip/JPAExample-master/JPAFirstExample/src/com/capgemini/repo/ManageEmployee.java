package com.capgemini.repo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.beans.Employee;

public class ManageEmployee {

	private static EntityManagerFactory factory;

	public static void main(String[] args) {

		factory = Persistence.createEntityManagerFactory("Employee-Service");

		Employee emp1 = new Employee();
		emp1.setFirst_name("John");
		emp1.setLast_name("Smith");
		emp1.setSalary(5000);

		Employee emp2 = new Employee();
		emp2.setFirst_name("David");
		emp2.setLast_name("Stephen");
		emp2.setSalary(2000);

		// insertEmployee(emp1);
		// insertEmployee(emp2);

		// updateEmployee(10, 1000);

		// readEmployee(10);

		// deleteEmployee(10);

		factory.close();

	}

	private static void insertEmployee(Employee emp) {
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		em.persist(emp);
		em.getTransaction().commit();
		em.close();
	}

	private static void readEmployee(int id) {
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		Employee emp = em.find(Employee.class, id);
		System.out.println("Id : " + emp.getId() + "\nName : " + emp.getFirst_name() + " " + emp.getLast_name()
				+ "\nSalary : " + emp.getSalary());
		em.close();

	}

	private static void updateEmployee(int id, double salary) {
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		Employee emp = em.find(Employee.class, id);
		emp.setSalary(salary);
		em.getTransaction().commit();
		em.close();
	}

	private static void deleteEmployee(int id) {
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		Employee emp = em.find(Employee.class, id);
		em.remove(emp);
		em.getTransaction().commit();
		em.close();

	}

}
